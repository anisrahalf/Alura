namespace DIO.Series
{
	public enum Genero
	{
		Acao = 1,
		Aventura = 2,
		Comedia = 3,
		Documentario = 4,
		Drama = 5,
		Espionagem = 6,
		Faroeste = 7,
		Fantasia = 8,
		Ficcao_Cientifica = 9,
		Musical = 10,
		Romance = 11,
		Suspense = 12,
		Terror = 13,
		Auto_Ajuda = 14,
		Nacionais = 15,
		Bollywood = 16,
		Ganhadores_Oscar = 17,
		Comedia_Romantica = 18,
		Historia = 19,
		Artes_Marciais = 20
	}
}