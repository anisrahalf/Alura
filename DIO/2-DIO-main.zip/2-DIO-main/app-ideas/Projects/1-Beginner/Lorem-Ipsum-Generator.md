# Lorem Ipsum Generator

**Tier:** 1-Beginner

Lorem Ipsum is simply dummy text of the printing and typesetting industry.
This app should generate passages of lorem ipsum text suitable for use as placeholder copy in web pages, graphics, and more.

## User Stories

-   [ ] User can type into an input field the number of paragraphs of lorem ipsum to be generated
-   [ ] Use can see the generated paragraphs of lorem ipsum and is able to copy them

## Trello Board

You can track your progress by cloning this [Trello Board](https://trello.com/b/T0xA0Glj/lorem-ipsum-generator)

## Useful links and resources

-   [lorem-ipsum npm package](https://www.npmjs.com/package/lorem-ipsum)
-   [lorem-ipsum CDN](https://www.jsdelivr.com/package/npm/lorem-ipsum)

## Example projects

-   [Lipsum.com](https://www.lipsum.com/)
