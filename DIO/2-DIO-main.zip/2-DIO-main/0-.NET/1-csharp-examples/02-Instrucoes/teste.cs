{
    public int x, y;
    public Ponto(int x, int y)
    {
    this.x = x;
    this.y = y;
    }
}
