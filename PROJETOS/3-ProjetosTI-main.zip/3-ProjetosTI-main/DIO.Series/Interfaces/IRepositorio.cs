using System.Collections.Generic;

namespace DIO.Series.Interfaces
{
    public interface IRepositorio<T> // T = tipo genérico, na hora de compilar substitui o T pela Serie
    {
        List<T> Lista(); // interface recebe um método que chama lista que retorna uma lista de T
        T RetornarPorId (int id); // passa um id por parametro e retorna um T como param
        void Insere(T entidade); // vai receber uma Serie
        void Exclui(int id); 
        void Atualiza(int id, T entidade); // recebe um Id e a entidade
        int ProximoId(); // retorna o prox id

    }
}