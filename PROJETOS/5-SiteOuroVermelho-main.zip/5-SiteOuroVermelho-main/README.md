# 5-SiteOuroVermelho
Site construído a partir do site da barbearia Alura, disponível no curso de HTML5 e CSS3
